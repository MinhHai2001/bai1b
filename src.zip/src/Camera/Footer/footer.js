import React, { Component } from 'react';

class Footer extends Component {

    render() {
        return (
            <div id="footer"> 
        <div id="btfooter">
          Copyright © 2015 Passerelles Numeriques.org. All rights reserved.<br />
          <a href="index.html#">Products</a>
          &nbsp;|&nbsp;
          <a href="index.html">Service</a>
          &nbsp;|&nbsp;
          <a href="index.html">About Us</a>
          &nbsp;|&nbsp;
        </div>
      </div>
        );
    }
}

export default Footer;