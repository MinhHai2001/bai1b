export default function getData() {
    return [
        {
            name: "QUÂN SỰ - QUỐC pHÒNG",
            image: "pic1.png",
            type: "QUÂN SỰ-QUỐC PHÒNG",
            content:"Nga phát triển tên lửa đạn đạo liên tục địa thế hệ mới \n \ Irael và Hy Lạp ký thỏa thuận quốc phòng lớn nhất từ trước đến nay  \n \ Người Mĩ nghi nga có xe tăng chiến đấu chủ lực bí mật"
        },
        {
            name: "TÌNH YÊU-GIA ĐÌNH",
            image: "pic2.png",
            type: "TÌNH YÊU-GIA ĐÌNH",
            content:"Những điều cần biết về việc nuôi con bằng sữa mẹ \n \ Những điều cần ghi nhớ trước khi vào cuộc sống hôn nhân.  \n \ Việc đưa ra lời khuyên ảnh hưởng tới mối quan hệ của bạn như thế nào?"
        },
        {
            name: "NGƯỜI VIỆT",
            image: "pic3.png",
            type: "NGƯỜI VIỆT",
            content:"Cộng đồng Việt Nam tại Séc đoàn kết vượt qua đại dịch Covid-19.\n \ Kiều bào tại Australia đặt nhiều kì vọng vào đội ngũ lãnh đạo mới của Đảng.\n \ Người cha nâng cánh ước mơ cho những đứa trẻ Việt Kiều khó khăn."
        },
        
    
    ];
} 